// script.js

document.addEventListener("DOMContentLoaded", () => {
    const images = document.querySelectorAll(".pizza-gallery .image-container img");
    const container = document.querySelector(".pizza-gallery .image-container");
    const prevBtn = document.querySelector(".pizza-gallery .prev");
    const nextBtn = document.querySelector(".pizza-gallery .next");

    let currentIndex = 0;

    function updateGallery() {
        const offset = -currentIndex * (images[0].clientWidth + 30); // Account for margin
        container.style.transform = `translateX(${offset}px)`;
    }

    // Move to the next image
    nextBtn.addEventListener("click", () => {
        currentIndex = (currentIndex + 1) % images.length;
        updateGallery();
    });

    // Move to the previous image
    prevBtn.addEventListener("click", () => {
        currentIndex = (currentIndex - 1 + images.length) % images.length;
        updateGallery();
    });

    // Auto-swipe every 3 seconds
    setInterval(() => {
        currentIndex = (currentIndex + 1) % images.length;
        updateGallery();
    }, 3000);
});
